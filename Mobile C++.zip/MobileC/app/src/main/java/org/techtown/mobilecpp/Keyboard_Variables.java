package org.techtown.mobilecpp;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class Keyboard_Variables extends Fragment {
    ListView another_var_list;
    ListView standard_var_list;
    ListViewAdapter adapter_another, adapter_standard;
    Button addButton;

    @Nullable
    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle bundle) {
        View view = inflater.inflate(R.layout.fragment_keyboard_variable, container, false);

        another_var_list = view.findViewById(R.id.another_var_list);
        standard_var_list = view.findViewById(R.id.standard_var_list);

        adapter_another = new ListViewAdapter();
        adapter_standard = new ListViewAdapter();

        another_var_list.setAdapter(adapter_another);
        standard_var_list.setAdapter(adapter_standard);

        adapter_another.mode = 1;

        refreshList();

        addButton = view.findViewById(R.id.add_button);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity) requireActivity()).addAnother();
            }
        });

        return view;
    }

    void refreshList() {
        adapter_standard.setItems(((MainActivity) requireActivity()).get_list_standard());
        adapter_another.setItems(((MainActivity) requireActivity()).get_list_another());
    }

    public class ListViewAdapter extends BaseAdapter {
        int mode = 0;
        ArrayList<String> items = new ArrayList<String>();

        public void addItem(String str) {
            items.add(str);
        }

        public void setItems(ArrayList<String> newItems) {
            items = newItems;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int i) {
            return items.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View convertView, ViewGroup viewGroup) {
            final Context context = viewGroup.getContext();
            final String str = items.get(i);

            if(convertView == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.list_button, viewGroup, false);

            } else {
                View view = new View(context);
                view = (View) convertView;
            }

            Button button = convertView.findViewById(R.id.list_button);
            button.setText(str);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.d("Keyboard_Variables", "button clicked");
                    ((MainActivity) requireActivity()).add(str);
                }
            });

            button.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    if (mode == 1) {
                        ((MainActivity) requireActivity()).removeAnother(str);
                    }
                    return true;
                }
            });

            return convertView;  //뷰 객체 반환
        }
    }
}
