package org.techtown.mobilecpp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class MainActivity extends AppCompatActivity {

    public static final List<Character> breakpoint = List.of('.', ' ', ',', '\n', '\t', '(', ')', '{', '}', '[', ']', '<', '>', '?', ':', ';', '!', '@', '#', '+', '-', '*', '/', '\\', '|', '&', '%', ',', '.', '?');
    private static final String TAG = "MainActivity";

    String[] cppStandard;

    ArrayList<String> cppAnother = new ArrayList<String>();

    Button keyboardEnglishButton, keyboardSpecialButton, keyboardVariableButton;

    Keyboard_English keyboardEnglish;
    Keyboard_Special_Characters keyboardSpecialCharacters;
    Keyboard_Variables keyboardVariables;

    EditText sourceCode;
    TextView rows;

    Button Key_ctrl, Key_space, Key_enter;

    void initValue() {
        cppStandard = new String[] {
                "alignas", "alignof", "asm", "auto", "bool", "break", "case", "catch",
                "char", "char16_t", "char32_t", "class", "const", "constexpr",
                "const_cast", "continue", "decltype", "default", "delete",
                "do", "double", "dynamic_cast", "else", "enum", "explicit",
                "export", "extern", "false", "final", "float", "for", "friend",
                "goto", "if", "inline", "int", "long", "mutable", "namespace",
                "new", "noexcept", "nullptr", "operator", "override", "private",
                "protected", "public", "register", "reinterpret_cast", "return",
                "short", "signed", "sizeof", "static", "static_assert", "static_cast",
                "struct", "switch", "template", "this", "thread_local", "throw",
                "true", "try", "typedef", "typei'", "typename", "union",
                "unsigned", "using", "virtual", "void", "volatile", "wchar_t",
                "while" };
    }

    boolean isPrefix(String S, String T) {
        int n, m;
        n = S.length();
        m = T.length();
        if (n < m) return false;
        int i;
        for (i = 0; i < m; i++) if (S.charAt(i) != T.charAt(i)) return false;
        return true;
    }

    boolean isBreakPoint(char c) {
        for (Character x : breakpoint) if (c == x) return true;
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        checkPermission();
        initValue();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rows = findViewById(R.id.source_rows);
        rows.setMovementMethod(new ScrollingMovementMethod());

        keyboardEnglishButton = findViewById(R.id.button_keyboard_english);
        keyboardSpecialButton = findViewById(R.id.button_special_characters);
        keyboardVariableButton = findViewById(R.id.button_keyboard_variable);

        keyboardEnglish = new Keyboard_English();
        keyboardSpecialCharacters = new Keyboard_Special_Characters();
        keyboardVariables = new Keyboard_Variables();
        getSupportFragmentManager().beginTransaction().replace(R.id.layout_keyboard_keybuttons, keyboardEnglish).commit();

        keyboardEnglishButton.setOnClickListener(view -> getSupportFragmentManager().beginTransaction().replace(R.id.layout_keyboard_keybuttons, keyboardEnglish).commit());
        keyboardSpecialButton.setOnClickListener(view -> getSupportFragmentManager().beginTransaction().replace(R.id.layout_keyboard_keybuttons, keyboardSpecialCharacters).commit());
        keyboardVariableButton.setOnClickListener(view -> {
            getSupportFragmentManager().beginTransaction().replace(R.id.layout_keyboard_keybuttons, keyboardVariables).commit();
            //keyboardVariables.refreshList();
        });

        sourceCode = findViewById(R.id.source_code);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) sourceCode.setShowSoftInputOnFocus(false);

        Key_space = findViewById(R.id.keyboard_key_space);

        Key_space.setOnClickListener(view -> send(" "));

        Key_enter = findViewById(R.id.keyboard_key_enter);

        Key_enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int indent = getIndent();
                send("\n");
                for (int i = 1; i <= indent; i++) send(" ");
                updateRows();
            }
        });

        sourceCode.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View view, int i, int i1, int i2, int i3) {
                updateRows();
                Log.d("MainActivity", Integer.toString(i1));
                rows.scrollTo(0, i1);
            }
        });

        sourceCode.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                updateRows();
            }
        });

        rows.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View view, int i, int i1, int i2, int i3) {
                updateRows();
                Log.d("MainActivity", Integer.toString(i1));
                sourceCode.scrollTo(0, i1);
            }
        });

    }

    public void checkPermission() {
        String[] PERMISSIONS = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        ActivityCompat.requestPermissions(this,PERMISSIONS, 0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    private static final int FILE_SELECT_LOAD_CODE = 0;
    private static final int FILE_SELECT_SAVE_CODE = 1;

    private void writeToFile() {
        /*
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addCategory(Intent.CATEGORY_DEFAULT);
        startActivityForResult(Intent.createChooser(i, "Choose directory"), FILE_SELECT_SAVE_CODE);

         */
        File storeDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
        if (!storeDir.exists()) {
            if (!storeDir.mkdirs()) {
                Log.d("MyDocApp", "failed to create directory");
                return;
            }
        }
        File file = new File(storeDir.getPath() + File.separator + "source.cpp");
        Log.d(TAG, file.getPath());
        if (file == null){
            Log.d(TAG, "Error at creating .docx file, check storage permissions :");
            return;
        }
        FileOutputStream stream = null;
        try {
            stream = new FileOutputStream(file);
            Log.d(TAG, "1");
            stream.write(sourceCode.getText().toString().getBytes());
            Log.d(TAG, "2");
            sourceCode.setText(sourceCode.getText().toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showFileChooser() {
        checkPermission();
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try {
            startActivityForResult(
                    Intent.createChooser(intent, "Select a File to Upload"),
                    FILE_SELECT_LOAD_CODE);
        } catch (android.content.ActivityNotFoundException ex) {
            // Potentially direct the user to the Market with a Dialog
            Toast.makeText(this, "Please install a File Manager.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    public static String getPathFromUri(Uri uri) {
        File file = new File(uri.getPath());//create path from uri
        final String[] split = file.getPath().split(":");//split the path.
        return split[1];//assign it to a string(your choice).

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        checkPermission();
        switch (requestCode) {
            case FILE_SELECT_LOAD_CODE:
                if (resultCode == RESULT_OK) {
                    Uri uri = data.getData();
                    Log.d(TAG, "File Uri: " + uri.toString());
                    File file = new File(uri.getPath());
                    Log.d(TAG, file.getPath());
                    try {
                        FileInputStream stream = new FileInputStream(file);
                        StringBuilder stringBuilder = new StringBuilder();
                        try (InputStream inputStream =
                                     getContentResolver().openInputStream(uri);
                             BufferedReader reader = new BufferedReader(
                                     new InputStreamReader(Objects.requireNonNull(inputStream)))) {
                            String line;
                            while ((line = reader.readLine()) != null) {
                                stringBuilder.append(line);
                            }
                        }
                        sourceCode.setText(stringBuilder.toString());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                break;
            case FILE_SELECT_SAVE_CODE:
                /*
                if (resultCode == RESULT_OK) {
                    Uri uri = data.getData();
                    Log.d(TAG, "File Uri: " + uri.toString());
                    //String path = getPathFromUri(uri);
                    File storeDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
                    path = file.getPath();
                    //File file = new File("/data");
                    Log.d(TAG, path + "/source.cpp");
                    Log.d(TAG, file.getAbsolutePath());
                    if (!file.exists()){
                        Log.d(TAG, "mkdir" + file.getPath());
                        //file.mkdirs();
                        try {
                            if (file.getParentFile().exists()){
                                Log.d(TAG, "parent file exists");
                            }
                            Log.d(TAG, file.getParentFile().getPath());
                            file.getParentFile().mkdirs();
                            file.createNewFile();
                        } catch (IOException e) {
                            Log.d(TAG, "error" + e.toString());
                            e.printStackTrace();
                        }
                    }
                    try {
                        FileOutputStream stream = new FileOutputStream(file);
                        Log.d(TAG, "1");
                        stream.write(sourceCode.getText().toString().getBytes());
                        Log.d(TAG, "2");
                        sourceCode.setText(sourceCode.getText().toString());
                    } catch (Exception e) {

                        Log.d(TAG, "error!!!!" + e.toString());
                        e.printStackTrace();
                    }
                }
                break;

                 */

        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.loadButton:
                showFileChooser();
                return true;
            case R.id.saveButton:
                writeToFile();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    void updateRows() {
        int lines = sourceCode.getLineCount();
        String rowLine = "";
        for (int i = 1; i < lines; i++) rowLine = rowLine + i + '\n';
        rowLine = rowLine + lines;
        rows.setText(rowLine);
    }

    String getInput() {
        int position = sourceCode.getSelectionStart() - 1;
        StringBuilder str = new StringBuilder();
        while (position >= 0) {
            char c = sourceCode.getText().charAt(position);
            if (isBreakPoint(sourceCode.getText().charAt(position))) break;
            str.append(c);
            position--;
        }
        str.reverse();
        return str.toString();
    }

    int getIndent() {
        int pos = sourceCode.getSelectionEnd();
        pos--;
        while (pos >= 0 && sourceCode.getText().toString().charAt(pos) != '\n') pos--;
        int ans = 1;
        Log.d(TAG, Integer.toString(pos));
        for (; pos + ans < sourceCode.length() && sourceCode.getText().toString().charAt(pos + ans) == ' '; ans++);

        Log.d(TAG, Integer.toString(ans));
        return ans - 1;
    }

    public ArrayList<String> get_list_standard() {
        String T = getInput();
        ArrayList<String> res = new ArrayList<>();
        int i;
        for (i = 0; i < cppStandard.length; i++) if (isPrefix(cppStandard[i], T)) res.add(cppStandard[i]);
        return res;
    }

    public ArrayList<String> get_list_another() {
        String T = getInput();
        ArrayList<String> res = new ArrayList<>();
        int i;
        for (String s : cppAnother) if (isPrefix(s, T)) res.add(s);
        return res;
    }

    private boolean shift = false;
    private boolean autoShift = false;

    public void send(String str) {
        if (shift) {
            if ('a' <= str.charAt(0) && str.charAt(0) <= 'z') {
                str = "" + ((char) (str.charAt(0) - 32));
            }
        }
        int cursorLocation = sourceCode.getSelectionStart();
        sourceCode.getText().insert(cursorLocation, str);
        updateRows();
        if (shift && !autoShift) {
            shift = false;
            keyboardEnglish.updateShift(shift, autoShift);
        }
    }

    public void add(String str) {
        int n = getInput().length();
        if (n != str.length()) sourceCode.getText().insert(sourceCode.getSelectionStart(), str.substring(n));
        send(" ");
        keyboardVariables.refreshList();
        updateRows();
    }

    public void shift() {
        if (!shift) shift = true;
        else if (!autoShift) autoShift = true;
        else shift = autoShift = false;
        keyboardEnglish.updateShift(shift, autoShift);
    }

    public void backspace() {
        int s = sourceCode.getSelectionStart();
        int e = sourceCode.getSelectionEnd();
        if (s == e) {
            s--;
            if (s < 0) s = 0;
            String str = sourceCode.getText().toString().substring(0, s);
            str = str + sourceCode.getText().toString().substring(e, sourceCode.length());
            sourceCode.setText(str);
        }
        else {
            String str = sourceCode.getText().toString().substring(0, s);
            str = str + sourceCode.getText().toString().substring(e, sourceCode.length());
            sourceCode.setText(str);
        }
        sourceCode.setSelection(s);
        int pos = sourceCode.getSelectionEnd();
    }

    public void removeAnother(String str) {
        cppAnother.remove(str);
        keyboardVariables.refreshList();
    }

    public String getSelected() {
        int s, e;
        s = sourceCode.getSelectionStart();
        e = sourceCode.getSelectionEnd();
        Log.d("MainActivity", s + " " + e);
        return sourceCode.getText().toString().substring(s, e);
    }

    public void addAnother() {
        String S = getSelected();
        if (S.length() >= 1) cppAnother.add(S);
        keyboardVariables.refreshList();
    }

}