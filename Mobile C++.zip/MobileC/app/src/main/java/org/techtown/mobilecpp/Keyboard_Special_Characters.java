package org.techtown.mobilecpp;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.jetbrains.annotations.NotNull;

public class Keyboard_Special_Characters extends Fragment {

    Button keyboard_key_tilde, keyboard_key_comma, keyboard_key_parentheses, keyboard_key_curly_brackets, keyboard_key_square_brackets, keyboard_key_inequality_sign, keyboard_key_plusminus, keyboard_key_multi_divide, keyboard_key_percent, keyboard_key_cramps, keyboard_key_sharp, keyboard_key_dollar, keyboard_key_question, keyboard_key_colon, keyboard_key_quote, keyboard_key_bitoper, keyboard_key_backslash, keyboard_key_underbar, keyboard_key_equal;

    @Nullable
    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle bundle) {
        View view = inflater.inflate(R.layout.fragment_keyboard__special__characters, container, false);


        keyboard_key_parentheses = view.findViewById(R.id.keyboard_key_parentheses);
        keyboard_key_parentheses.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("("));
        keyboard_key_parentheses.setOnLongClickListener(view12 -> {((MainActivity) getActivity()).send(")"); return true; });
        keyboard_key_curly_brackets = view.findViewById(R.id.keyboard_key_curly_brackets);
        keyboard_key_curly_brackets.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("{"));
        keyboard_key_curly_brackets.setOnLongClickListener(view12 -> {((MainActivity) getActivity()).send("}"); return true; });
        keyboard_key_square_brackets = view.findViewById(R.id.keyboard_key_square_brackets);
        keyboard_key_square_brackets.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("["));
        keyboard_key_square_brackets.setOnLongClickListener(view12 -> {((MainActivity) getActivity()).send("]"); return true; });
        keyboard_key_inequality_sign = view.findViewById(R.id.keyboard_key_inequality_sign);
        keyboard_key_inequality_sign.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("<"));
        keyboard_key_inequality_sign.setOnLongClickListener(view12 -> {((MainActivity) getActivity()).send(">"); return true; });
        keyboard_key_plusminus = view.findViewById(R.id.keyboard_key_plusminus);
        keyboard_key_plusminus.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("+"));
        keyboard_key_plusminus.setOnLongClickListener(view12 -> {((MainActivity) getActivity()).send("-"); return true; });
        keyboard_key_multi_divide = view.findViewById(R.id.keyboard_key_multi_divide);
        keyboard_key_multi_divide.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("*"));
        keyboard_key_multi_divide.setOnLongClickListener(view12 -> {((MainActivity) getActivity()).send("/"); return true; });
        keyboard_key_question = view.findViewById(R.id.keyboard_key_question);
        keyboard_key_question.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("!"));
        keyboard_key_question.setOnLongClickListener(view12 -> {((MainActivity) getActivity()).send("?"); return true; });
        keyboard_key_colon = view.findViewById(R.id.keyboard_key_colon);
        keyboard_key_colon.setOnClickListener(view1 -> ((MainActivity) getActivity()).send(";"));
        keyboard_key_colon.setOnLongClickListener(view12 -> {((MainActivity) getActivity()).send(":"); return true; });
        keyboard_key_comma = view.findViewById(R.id.keyboard_key_comma);
        keyboard_key_comma.setOnClickListener(view1 -> ((MainActivity) getActivity()).send(","));
        keyboard_key_comma.setOnLongClickListener(view12 -> {((MainActivity) getActivity()).send("."); return true; });
        keyboard_key_quote = view.findViewById(R.id.keyboard_key_quote);
        keyboard_key_quote.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("\""));
        keyboard_key_quote.setOnLongClickListener(view12 -> {((MainActivity) getActivity()).send("'"); return true; });
        keyboard_key_bitoper = view.findViewById(R.id.keyboard_key_bitoper);
        keyboard_key_bitoper.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("&"));
        keyboard_key_bitoper.setOnLongClickListener(view12 -> {((MainActivity) getActivity()).send("|"); return true; });

        keyboard_key_percent = view.findViewById(R.id.keyboard_key_percent);
        keyboard_key_percent.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("%"));
        keyboard_key_cramps = view.findViewById(R.id.keyboard_key_cramps);
        keyboard_key_cramps.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("^"));
        keyboard_key_sharp = view.findViewById(R.id.keyboard_key_sharp);
        keyboard_key_sharp.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("#"));
        keyboard_key_dollar = view.findViewById(R.id.keyboard_key_dollar);
        keyboard_key_dollar.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("$"));
        keyboard_key_backslash = view.findViewById(R.id.keyboard_key_backslash);
        keyboard_key_backslash.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("\\"));
        keyboard_key_tilde = view.findViewById(R.id.keyboard_key_tilde);
        keyboard_key_tilde.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("~"));
        keyboard_key_underbar = view.findViewById(R.id.keyboard_key_underbar);
        keyboard_key_underbar.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("_"));
        keyboard_key_equal = view.findViewById(R.id.keyboard_key_equal);
        keyboard_key_equal.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("="));
        return view;
    }
}
