package org.techtown.mobilecpp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.jetbrains.annotations.NotNull;

public class Keyboard_English extends Fragment {
    Button Key_a, Key_b, Key_c, Key_d, Key_e, Key_f, Key_g, Key_h, Key_i, Key_j, Key_k, Key_l, Key_m, Key_n, Key_o, Key_p, Key_q, Key_r, Key_s, Key_t, Key_u, Key_v, Key_w, Key_x, Key_y, Key_z;
    Button Key_0, Key_1, Key_2, Key_3, Key_4, Key_5, Key_6, Key_7, Key_8, Key_9;
    Button Key_shift, Key_backspace;

    @Nullable
    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle bundle) {
        View view = inflater.inflate(R.layout.fragment_keyboard_english, container, false);
        Key_a = view.findViewById(R.id.keyboard_key_a);
        Key_a.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("a"));
        Key_b = view.findViewById(R.id.keyboard_key_b);
        Key_b.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("b"));
        Key_c = view.findViewById(R.id.keyboard_key_c);
        Key_c.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("c"));
        Key_d = view.findViewById(R.id.keyboard_key_d);
        Key_d.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("d"));
        Key_e = view.findViewById(R.id.keyboard_key_curly_brackets);
        Key_e.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("e"));
        Key_f = view.findViewById(R.id.keyboard_key_f);
        Key_f.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("f"));
        Key_g = view.findViewById(R.id.keyboard_key_g);
        Key_g.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("g"));
        Key_h = view.findViewById(R.id.keyboard_key_h);
        Key_h.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("h"));
        Key_i = view.findViewById(R.id.keyboard_key_question);
        Key_i.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("i"));
        Key_j = view.findViewById(R.id.keyboard_key_j);
        Key_j.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("j"));
        Key_k = view.findViewById(R.id.keyboard_key_k);
        Key_k.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("k"));
        Key_l = view.findViewById(R.id.keyboard_key_l);
        Key_l.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("l"));
        Key_m = view.findViewById(R.id.keyboard_key_m);
        Key_m.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("m"));
        Key_n = view.findViewById(R.id.keyboard_key_n);
        Key_n.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("n"));
        Key_o = view.findViewById(R.id.keyboard_key_o);
        Key_o.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("o"));
        Key_p = view.findViewById(R.id.keyboard_key_comma);
        Key_p.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("p"));
        Key_q = view.findViewById(R.id.keyboard_key_inequality_sign);
        Key_q.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("q"));
        Key_r = view.findViewById(R.id.keyboard_key_square_brackets);
        Key_r.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("r"));
        Key_s = view.findViewById(R.id.keyboard_key_s);
        Key_s.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("s"));
        Key_t = view.findViewById(R.id.keyboard_key_t);
        Key_t.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("t"));
        Key_u = view.findViewById(R.id.keyboard_key_colon);
        Key_u.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("u"));
        Key_v = view.findViewById(R.id.keyboard_key_v);
        Key_v.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("v"));
        Key_w = view.findViewById(R.id.keyboard_key_parentheses);
        Key_w.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("w"));
        Key_x = view.findViewById(R.id.keyboard_key_x);
        Key_x.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("x"));
        Key_y = view.findViewById(R.id.keyboard_key_quote);
        Key_y.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("y"));
        Key_z = view.findViewById(R.id.keyboard_key_z);
        Key_z.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("z"));

        Key_0 = view.findViewById(R.id.keyboard_key_0);
        Key_0.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("0"));
        Key_1 = view.findViewById(R.id.keyboard_key_1);
        Key_1.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("1"));
        Key_2 = view.findViewById(R.id.keyboard_key_2);
        Key_2.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("2"));
        Key_3 = view.findViewById(R.id.keyboard_key_3);
        Key_3.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("3"));
        Key_4 = view.findViewById(R.id.keyboard_key_4);
        Key_4.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("4"));
        Key_5 = view.findViewById(R.id.keyboard_key_5);
        Key_5.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("5"));
        Key_6 = view.findViewById(R.id.keyboard_key_6);
        Key_6.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("6"));
        Key_7 = view.findViewById(R.id.keyboard_key_7);
        Key_7.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("7"));
        Key_8 = view.findViewById(R.id.keyboard_key_8);
        Key_8.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("8"));
        Key_9 = view.findViewById(R.id.keyboard_key_9);
        Key_9.setOnClickListener(view1 -> ((MainActivity) getActivity()).send("9"));


        Key_shift = view.findViewById(R.id.keyboard_key_shift);
        Key_shift.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity) getActivity()).shift();
            }
        });

        updateShift(false, false);

        Key_backspace = view.findViewById(R.id.keyboard_key_backspace);
        Key_backspace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity) getActivity()).backspace();
            }
        });
        return view;
    }

    void updateShift(boolean shift, boolean autoShift){
        if (!shift) {
            Key_shift.setText("low");
        }
        else if(!autoShift) {
            Key_shift.setText("upp");
        }
        else {
            Key_shift.setText("UPP");
        }
    }
}
