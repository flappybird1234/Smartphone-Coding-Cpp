package org.techtown.mobilecpp;

import org.antlr.v4.runtime.ParserRuleContext;

public class Mylistener extends CPP14ParserBaseListener {
    StringBuilder sb = new StringBuilder("");
    @Override public void enterEveryRule(ParserRuleContext ctx) {


        //sb = new StringBuilder(sb + (ctx.getText() + ' '));

    }
    @Override public void enterNewDeclarator(CPP14Parser.NewDeclaratorContext ctx) {
        sb = new StringBuilder(sb + (ctx.getText() + ' '));
    }
    String getLog() {
        return sb.toString();
    }
}
